from setuptools import setup

setup(
	name = "paquetecalculos",
	version = "1.0",
	descripcion = "Paquete de redondeo y potencias",
	author = "Juan",
	author_email = "a@a.com",
	url = "www.google.es",
	packages = ["_35_calculos", "_35_calculos.redondeo_potencia"]
	)